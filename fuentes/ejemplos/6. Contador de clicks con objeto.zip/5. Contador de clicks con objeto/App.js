import logo from './logo.svg';
import './App.css';
import Contador from './componentes/Contador';

function App() {
  return (
    <div>
      <Contador></Contador>
    </div>
  );
}

export default App;
