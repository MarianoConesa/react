const losCoches = [
    {
        modelo    : 'Renault Megane',
        matricula : '5656KFL',
        color     : 'rojo',
        npuertas  :  3
    },
    {
        modelo    : 'Alfa Romeo Giulia',
        matricula : '3216LFL',
        color     : 'negro',
        npuertas  :  4
    },
    {
        modelo    : 'Jeep Renegade',
        matricula : '5656LRG',
        color     : 'naranja',
        npuertas  :  5
    }  
  
   ];

export default losCoches;