import React from 'react';

// Creamos un contexto
const TemaContext = React.createContext();

export default TemaContext;