
import React, { useState } from 'react'

const Contador = (props) => {

    const [valorContador, setContador] = useState(+props.contador);

    // Función encargada de incrementar el contador haciendo
    // uso del hook
    function incrementarContador() {
      setContador(valorContador + 1);
    }

    // Función encargada de resetear el contador haciendo
    // uso del hook
    function resetearContador() {
      setContador(+props.contador);
    }

    const esPar = valorContador%2 === 0;
    
    // Evaluación ternaria
    const mensaje = esPar ? "Es par" : "Es impar";

/*
    // Estas tres líneas son equivalentes a una sola línea con una evaluación ternaria
    let mensajePar="";
    if (esPar) mensajePar= "Es par";
    else mensajePar="Es impar";
*/  

  // -------------------------------------------------------------------------------


    return (
      <div>
        <p>El valor del contador es</p>
        <h1>{valorContador}</h1>
        <p>{mensaje}</p>
        <button onClick={incrementarContador}> Incrementa contador </button>
        <button onClick={resetearContador}> Resetear contador </button>
      </div>
    )
}

export default Contador;

