import React, { useEffect, useState } from 'react'

const Contador = (props) => {

    const [valorContador, setContador] = useState(+props.contador);

    // Función encargada de incrementar el contador haciendo
    // uso del hook de estado
    function incrementarContador() {
      
      setContador(valorContador=>valorContador + 1);      
    }

    function contador(){

      setInterval(incrementarContador, 1000);
    }

    // Lanzamos el efecto animación y gracias a [] solo una vez
    useEffect(contador, []);

    return (
      <div>
        <p>El valor del contador es</p>
        <h1>{valorContador}</h1>
      </div>
    )
}

export default Contador;

