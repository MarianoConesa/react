import './App.css';
import Contador from './componentes/Contador';

function App() {

  return (
    <div>
      <Contador contador="0"></Contador>
    </div>
  );
}

export default App;
