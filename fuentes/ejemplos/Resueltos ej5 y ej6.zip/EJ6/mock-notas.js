const notas = [
    {
      id: 1,
      contenido: 'HTML is easy',
      fecha: '2019-05-30T17:30:31.098Z',
      importante: true
    },
    {
      id: 2,
      contenido: 'Browser can execute only JavaScript',
      fecha: '2019-05-30T18:39:34.091Z',
      importante: false
    },
    {
      id: 3,
      contenido: 'GET and POST are the most important methods of HTTP protocol',
      fecha: '2019-05-30T19:20:14.298Z',
      importante: true
    }
  ]

  export default notas;