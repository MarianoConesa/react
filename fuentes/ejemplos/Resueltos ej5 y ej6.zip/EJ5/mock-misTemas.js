const misTemas = [

    {
        id: 1,
        name: 'UT1. Javascript. Referencia del lenguaje',
        parts: [
        {
            name: 'Arrays',
            exercises: 10,
            id: 1
        },
        {
            name: 'Funciones',
            exercises: 7,
            id: 2
        },
        {
            name: 'Objetos',
            exercises: 14,
            id: 3
        }
        ]
    },
    {
        id: 2,
        name: 'UT2. Javascript. Interacción con el navegador',
        parts: [
        {
            name: 'Dom',
            exercises: 5,
            id: 1
        },
        {
            name: 'Bom',
            exercises: 9,
            id: 2
        },
        {
            name: 'Animaciones',
            exercises: 12,
            id: 3
        }
        ]
    }    
]

export default misTemas;