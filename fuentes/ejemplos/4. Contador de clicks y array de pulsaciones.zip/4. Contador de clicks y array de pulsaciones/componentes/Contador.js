import React, { useState } from 'react'

const Contador = (props) => {

    const [valorContador, setContador] = useState(+props.contador);

    const [clicks, setClicks] = useState([]);

    // Función encargada de incrementar el contador haciendo
    // uso del hook
    function incrementarContador() {
      setContador(valorContador + 1);
      setClicks( clicks.concat("i") );
    }

    // Función encargada de resetear el contador haciendo
    // uso del hook
    function resetearContador() {
      setContador(+props.contador);
      setClicks( [...clicks, "r"] );
    }

    const esPar = valorContador%2 === 0;    
    // Evaluación ternaria
    const mensaje = esPar ? "Es par" : "Es impar";


    return (
      <div>
        <p>El valor del contador es</p>
        <h1>{valorContador}</h1>
        <p>{mensaje}</p>        
        <p>{clicks}</p>
        <p>clicks totales {clicks.length}</p>        
        <button onClick={incrementarContador}> Incrementa contador </button>
        <button onClick={resetearContador}> Resetear contador </button>
      </div>
    )
}

export default Contador;







