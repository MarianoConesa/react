const frutas = ["Pera","Manzana","Melón","Sandía"]

export default frutas;