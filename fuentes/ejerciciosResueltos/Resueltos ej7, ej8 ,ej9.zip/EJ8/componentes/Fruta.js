const Fruta = (props) => {

    return (
        <li>{props.fruta}</li>
    )
}

export default Fruta;