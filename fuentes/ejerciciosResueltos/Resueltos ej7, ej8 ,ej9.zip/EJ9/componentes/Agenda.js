
const Agenda = (props) => {

    return (

        <li>{props.entrada.nombre}-{props.entrada.telefono}</li>

    )

}
export default Agenda;