const listinTelefonico =[
    {
      id : 1,
      nombre : "José Martínez",
      telefono : 968234567
    }, 
    {
      id : 2,
      nombre : "Antonio Tudela",
      telefono : 626665412
    }, 
    {
      id : 3,
      nombre : "María Menendez",
      telefono : 968765431
    }
];

export default listinTelefonico;
  