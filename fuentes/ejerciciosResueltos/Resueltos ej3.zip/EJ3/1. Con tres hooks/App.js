import './App.css';
import Semaforo from './componentes/Semaforo';

function App() {

  return (
    <div>
      <Semaforo></Semaforo>
    </div>
  );
}

export default App;
