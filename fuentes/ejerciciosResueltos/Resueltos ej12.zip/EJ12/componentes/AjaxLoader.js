import imagenLoader from '../img/ajax-loader.gif';

const AjaxLoader = () => {

    return (
        <div>
            <img src={imagenLoader} alt="ajax-loader"/>
        </div>
    )
}

export default AjaxLoader;