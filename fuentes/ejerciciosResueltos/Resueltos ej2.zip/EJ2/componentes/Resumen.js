import React from 'react'

const Resumen = (props) => {

    return (    

      <p>{props.titulo} {props.total} </p>

    )
}

export default Resumen;