import React from 'react'

const Titulo = (props) => {

    return (

      <h1>{props.curso}</h1>

    )
}

export default Titulo;
