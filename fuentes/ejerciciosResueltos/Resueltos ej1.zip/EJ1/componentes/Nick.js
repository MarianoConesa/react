import React from 'react'

const Avatar = (props) => {

    return (

        <span className="handle" > {props.nick} </span>
    )
}

export default Avatar;