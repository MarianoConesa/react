import React from 'react'

const Avatar = (props) => {

    return (

        <div className="message" >
        {props.tweet}
        </div>
    )
}

export default Avatar;