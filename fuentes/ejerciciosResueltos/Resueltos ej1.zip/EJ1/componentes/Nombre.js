import React from 'react'

const Nombre = (props) => {

    return (

        <span className="name" > {props.nombre} </span>
    )
}

export default Nombre;