import React from 'react'

const Avatar = (props) => {

    return (

        <span className="time" > {props.cuando} </span>
    )
}

export default Avatar;