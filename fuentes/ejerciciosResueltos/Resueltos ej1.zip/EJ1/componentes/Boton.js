import React from 'react'

const Boton = (props) => {

    return (
        <i className={props.clase} />
    )
}

export default Boton;