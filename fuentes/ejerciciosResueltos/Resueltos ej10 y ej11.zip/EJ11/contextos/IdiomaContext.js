import React from 'react';

// Creamos un contexto
const IdiomaContext = React.createContext();

export default IdiomaContext;