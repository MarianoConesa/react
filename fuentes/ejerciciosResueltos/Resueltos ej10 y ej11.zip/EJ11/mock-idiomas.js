// Usamos array asociativo
const idiomas = {
    "es" : {
      botonera: {op1: "Archivo",
                 op2: "Editar",
                 op3: "Terminal"
      },
      tema: {
          op1: "Claro",
          op2: "Oscuro"
      }
    },
    "gb" : {
        botonera: {op1: "File",
                   op2: "Edit",
                   op3: "Terminal"
        },
        tema: {
            op1: "Ligth",
            op2: "Dark"
        }        
      },
    "fr" : {
        botonera: {op1: "Archive",
                   op2: "Editeur",
                   op3: "Terminale"
        },
        tema: {
            op1: "Claire",
            op2: "Sombre"
        }        
      }      
    };
  export default idiomas;